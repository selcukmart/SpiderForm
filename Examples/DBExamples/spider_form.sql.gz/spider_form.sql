-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: localhost
-- Üretim Zamanı: 05 Şub 2022, 10:42:39
-- Sunucu sürümü: 10.4.8-MariaDB
-- PHP Sürümü: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `form_generator`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `address`
--

CREATE TABLE `address` (
  `id` int(11) NOT NULL,
  `type` enum('1','2') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1' COMMENT '1=>Fatura Adresi, 2=>Kargo Adresi',
  `user_id` int(11) NOT NULL,
  `address_identification` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `surname` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `postal_code` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `province` int(11) NOT NULL,
  `county` int(11) NOT NULL,
  `district` int(11) NOT NULL,
  `neighbourhood` int(11) NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `mobile_phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `mail` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `invoice_type` enum('1','2') COLLATE utf8_unicode_ci NOT NULL COMMENT '1=>Bireysel,2=>Kurumsal',
  `identification_number` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `nationality_tc_or_not` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1' COMMENT '0=>Değil,1=>Tc Uyruklu',
  `company_name` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `tax_department` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `tax_number` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `is_e_invoice_user` enum('0','1','2') COLLATE utf8_unicode_ci DEFAULT '2' COMMENT '0=>Hayır,1=>Evet,2=>''Atanmadı''',
  `parasut_id` int(10) UNSIGNED DEFAULT 0,
  `state` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Tablo döküm verisi `address`
--

INSERT INTO `address` (`id`, `type`, `user_id`, `address_identification`, `name`, `surname`, `address`, `postal_code`, `country`, `province`, `county`, `district`, `neighbourhood`, `phone`, `mobile_phone`, `mail`, `invoice_type`, `identification_number`, `nationality_tc_or_not`, `company_name`, `tax_department`, `tax_number`, `is_e_invoice_user`, `parasut_id`, `state`, `created_at`) VALUES
(7, '1', 8015, 'Work Adress', 'Joe', 'DOE', 'Test strasse berlin', '28100', '', 0, 0, 0, 0, '', '5542856789', NULL, '1', '3514950', '1', '', '', '', '2', 0, '1', '0000-00-00 00:00:00'),
(8, '2', 8015, 'Home Address', 'jane', 'DOEL', 'Penguen Street London', '28100', '', 0, 0, 0, 0, '', '5542823456', NULL, '1', '503044', '1', '', '', '', '2', 0, '1', '0000-00-00 00:00:00'),
(9, '1', 7997, 'The forest', 'Bee', 'Joe', 'Serengetti', '8666', '', 0, 0, 0, 0, '', '5589812345', NULL, '1', '986868', '1', '', '', '', '2', 0, '1', '0000-00-00 00:00:00'),
(10, '1', 8018, 'The Mars', 'Marsien', 'Jane', 'Big Mars Road, Mars', '74100', '', 0, 0, 0, 0, '', '5543981234', NULL, '1', '4110722', '1', '', '', '', '2', 0, '1', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `address_countries`
--

CREATE TABLE `address_countries` (
  `id` int(11) NOT NULL,
  `address_id` int(11) NOT NULL,
  `iso` char(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `address_countries`
--

INSERT INTO `address_countries` (`id`, `address_id`, `iso`) VALUES
(1, 7, 'us'),
(2, 7, 'gb');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `countries`
--

CREATE TABLE `countries` (
  `iso` char(2) NOT NULL,
  `name` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tablo döküm verisi `countries`
--

INSERT INTO `countries` (`iso`, `name`) VALUES
('us', 'USA'),
('gb', 'UK'),
('de', 'Germany');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tip` (`type`),
  ADD KEY `kul_id` (`user_id`),
  ADD KEY `cep_telefonu` (`mobile_phone`),
  ADD KEY `fatura_tipi` (`invoice_type`),
  ADD KEY `tc_kimlik_no` (`identification_number`),
  ADD KEY `is_e_fatura_user` (`is_e_invoice_user`),
  ADD KEY `parasut_id` (`parasut_id`);

--
-- Tablo için indeksler `address_countries`
--
ALTER TABLE `address_countries`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `address`
--
ALTER TABLE `address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=185371;

--
-- Tablo için AUTO_INCREMENT değeri `address_countries`
--
ALTER TABLE `address_countries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
